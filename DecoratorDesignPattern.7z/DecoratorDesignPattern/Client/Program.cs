﻿using Client.View;
using Decorator;
using System.IO;
using static System.Console;

namespace Client
{
    class Program
    {
        static void Main(string[] args)
        {
            IDesigner designer = new OuterBorderDecorator(new Designer());
            File.WriteAllText(@"D:\ShoppingCart\ShoppingCart.htm", designer.GetTableStyle());
            //var cartDetails = new ShoppingCart("IN").GetShoppingCartDetail();

            //DisplayReport(cartDetails);
            WriteLine("HTML table has been sucessfully created !!");
            ReadKey();
        }

        private static void DisplayReport(ShoppingCartDto dto)
        {
            var itemOrdered = dto.Orders;
            for (int i = 0; i < itemOrdered.Count; i++)
            {
                WriteLine($"Order Id: {itemOrdered[i].OrderId} " +
                $"Price: {itemOrdered[i].Price} " +
                $"Quantity: {itemOrdered[i].Quantity}");
            }

            WriteLine($"Total Price: {dto.TotalPrice}");
        }
    }
}
