﻿namespace Client.View
{
    interface IDesigner
    {
        string GetTableStyle();
    }
}
